# BasicPython
repository with basic tutorials for Python
