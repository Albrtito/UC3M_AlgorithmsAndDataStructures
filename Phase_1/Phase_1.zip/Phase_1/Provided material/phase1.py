from slistH import SList
from slistH import SNode

import sys


class SList2(SList):

    def delLargestSeq(self):
        # implement here your solution

        pass

    def fix_loop(self):
        # implement here your solution

        pass

    def create_loop(self, position):
        # this method is used to force a loop in a singly linked list
        if position < 0 or position > len(self) - 1:
            raise ValueError(f"Position out of range [{0} - {len(self) - 1}]")

        current = self._head
        i = 0

        # We reach position to save the reference
        while current and i < position:
            current = current.next
            i += 1

        # We reach to tail node and set the loop
        start_node = current
        print(f"Creating a loop starting from {start_node.elem}")
        while current.next:
            current = current.next
        current.next = start_node

    def leftrightShift(self, left, n):
        # implement here your solution

        pass


if __name__ == '__main__':

    l = SList2()
    print("list:", str(l))
    print("len:", len(l))

    for i in range(7):
        l.addLast(i + 1)

    print(l)
    print()

    l = SList2()
    print("list:", str(l))
    print("len:", len(l))

    for i in range(7):
        l.addLast(i + 1)

    print(l)
    print()

    # No loop yet, no changes applied
    l.fix_loop()
    print("No loop yet, no changes applied")
    print(l)
    print()

    # We force a loop
    l.create_loop(position=6)
    l.fix_loop()
    print("Loop fixed, changes applied")
    print(l)
    print()
    print()

    l = SList2()
    for i in [1, 2, 3, 4, 5]:
        l.addLast(i)
    print(l.delLargestSeq())

    l = SList2()
    for i in range(7):
        l.addLast(i + 1)

    print(l)
    l.leftrightShift(False, 2)
    print(l)
