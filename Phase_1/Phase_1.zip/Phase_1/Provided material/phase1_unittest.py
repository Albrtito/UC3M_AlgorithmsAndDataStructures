
import unittest
from phase1 import SList2

class Test(unittest.TestCase):


   	#setUp is a method which is ran before a test method is executed. 
   	#This is useful if you need some data (for example) to be present before running a test.
    def setUp(self):
	
        pass        
	
    
    
    
    
    
    
    
    #implement here your test cases

















        
if __name__ == "__main__":
    unittest.main()